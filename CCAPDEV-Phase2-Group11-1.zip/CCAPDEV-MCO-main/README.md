de Guzman, Joaquin Nicholas
Herrera, Rowell
Ughoc, Daniella

1. Download and unzip all files.
2. Open MongoDB Compass and create two collections. The first is must be named "reservations"
and the second must be named "users".
3. Next, import "userdb.reservations.json" to the reservations collection and at the same time
import "userdb.users.json" to the users collection.
4. Open CMD to the directory where the files were unzipped and run the following (make sure to run on localhost:3000):
-Install Command:
-npm init
-npm i express express-handlebars body-parser mongoose
-Node app.js