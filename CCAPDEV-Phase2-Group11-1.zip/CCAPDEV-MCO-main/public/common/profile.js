$(document).ready(function () {
    $("#edit-profile").click(function () {
        window.open('/edit-profile', 'newwindow', 'width=800,height=600');
        return false;
    });
});